using UnityEngine;

public enum ItemType { Helmet ,Armor, Pants, Shoes, Gloves, Sword, Pickaxe, Axe, Potion, Material }

public enum MaterialType {None, Cobre, Hierro, Madera, Cuero, Carne }

[System.Serializable]
public class Item
{
    public string itemName;
    public string description;
    public ItemType itemType;
    public int healthBonus;     // Aumenta la vida (para armadura, pantalón)
    public float speedBonus;    // Aumenta la velocidad (para zapatos)
    public int attackBonus;     // Aumenta el ataque (para guantes, espada)
    public int plusHealth;
    public int plusStamina;

    public bool isPickaxe;
    public bool isAxe;
    public bool isPotion;        // Pico y hacha son herramientas

    public float price;         // Precio del objeto
    public Sprite icon;         // Icono del objeto para la UI

    public bool isCraftingMaterial; //Si es un material para craftear algo
    public MaterialType materialType; //Tipo de material

    public GameObject itemPrefab;
}
