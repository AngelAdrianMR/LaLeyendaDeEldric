using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class DraggableItem : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    private Item item;
    private InventoryUI inventoryUI;
    private Transform parentAfterDrag;
    private Image image;

    public void SetItem(Item newItem, InventoryUI ui)
    {
        item = newItem;
        inventoryUI = ui;
        image = GetComponent<Image>();
        image.sprite = item.icon;
    }

    public Item GetItem()
    {
        return item;
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        parentAfterDrag = transform.parent;
        transform.SetParent(transform.root);
        transform.SetAsLastSibling();
        image.raycastTarget = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
        transform.position = eventData.position;
    }

    public void OnEndDrag(PointerEventData eventData)
    {
        transform.SetParent(parentAfterDrag);
        image.raycastTarget = true;
    }
}
