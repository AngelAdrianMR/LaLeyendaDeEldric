using UnityEngine;
using System.Collections.Generic;

public class MissionManager : MonoBehaviour
{
    public static MissionManager Instance;

    [SerializeField] public List<Mission> activeMissions = new List<Mission>();
    [SerializeField] public List<Mission> completedMissions = new List<Mission>();

    public MissionDatabase missionDatabase;

    void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    public void AddMissionById(string id)
    {
        if (activeMissions.Exists(m => m.id == id) || completedMissions.Exists(m => m.id == id)) return;

        Mission mission = missionDatabase.GetMissionById(id);
        if (mission != null)
        {
            Mission newMission = new Mission(mission.id, mission.missionName, mission.description)
            {
                requieredItemName = mission.requieredItemName,
                requieredCrafting = mission.requieredCrafting,
                coinReward = mission.coinReward,
                nextMissionId = mission.nextMissionId
            };

            newMission.Activate();
            activeMissions.Add(newMission);
            Debug.Log("Misión activada desde base de datos: " + newMission.missionName);
        
            var ui = FindObjectOfType<MissionUI>();
            if (ui != null && ui.gameObject.activeSelf)
            {
                ui.RefreshMissionUI();
            }
        }
        else
        {
            Debug.LogWarning("No se encontró la misión con ID: " + id);
        }
    }

    public void CompleteMission(string missionId)
    {
        Mission mission = activeMissions.Find(m => m.id == missionId);
        if (mission != null)
        {
            mission.Complete();
            activeMissions.Remove(mission);
            completedMissions.Add(mission);

            PlayerAtribute player = FindObjectOfType<PlayerAtribute>();
            if (player != null)
            {
                player.coins += mission.coinReward;
            }

            // Activar siguiente misión desde base de datos
            if (!string.IsNullOrEmpty(mission.nextMissionId))
            {
                AddMissionById(mission.nextMissionId);
            }

            MissionUI missionUI = FindObjectOfType<MissionUI>();
            if (missionUI != null)
            {
                missionUI.PopulateMissionList(); // O llama directo al método si es público
            }
        }
    }

    public Mission GetMissionById(string id)
    {
        return activeMissions.Find(m => m.id == id) ?? completedMissions.Find(m => m.id == id);
    }

    public void LoadMissionsFromSave(List<Mission> savedActive, List<Mission> savedCompleted)
    {
        activeMissions = new List<Mission>(savedActive);
        completedMissions = new List<Mission>(savedCompleted);
    }

}
