using UnityEngine;

public class UIMenu : MonoBehaviour
{
    public GameObject mainPanel;
    public GameObject settingsPanel;

    private bool isPaused = false;

    void Start()
    {
        // Buscar los paneles automáticamente
        mainPanel = GameObject.Find("Main");
        settingsPanel = GameObject.Find("Setting");

        if (mainPanel == null)
        {
            Debug.LogError("MainPanel no encontrado.");
        }
        if (settingsPanel == null)
        {
            Debug.LogError("SettingsPanel no encontrado.");
        }

        // Asegurar que los paneles estén desactivados al inicio
        if (mainPanel != null) mainPanel.SetActive(false);
        if (settingsPanel != null) settingsPanel.SetActive(false);
    }

    void Update()
    {
        // Control del menú con la tecla ESC
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            ToggleMenu();
        }
    }

    public void ToggleMenu()
    {
        if (mainPanel == null) return;
        isPaused = !isPaused;
        mainPanel.SetActive(isPaused);
        Time.timeScale = isPaused ? 0 : 1;
    }

    public void OpenSettings()
    {
        if (settingsPanel != null) settingsPanel.SetActive(true);
    }

    public void CloseSettings()
    {
        if (settingsPanel != null) settingsPanel.SetActive(false);
    }
}
