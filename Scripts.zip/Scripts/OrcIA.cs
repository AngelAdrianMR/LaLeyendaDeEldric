using UnityEngine;
using System.Collections;

public class OrcIA : MonoBehaviour
{
    public Transform player;  // Referencia al jugador
    public float detectionRange = 10f;  // Rango de detección para el jugador
    public float speed = 3f;  // Velocidad de movimiento del enemigo
    public float obstacleDetectionDistance = 2f;  // Distancia para detectar obstáculos
    public float knockbackForce = 3f;  // Fuerza de retroceso
    public int health = 20;
    public int attackDamage = 4;
    public GameObject dropItem;

    private Animator anim;
    private SpriteRenderer spriteRenderer;
    private Rigidbody2D rb;
    private bool isKnockedBack = false;

    void Start()
    {
        anim = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (player == null || isKnockedBack) return;

        float distance = Vector2.Distance(transform.position, player.position);

        if (distance < detectionRange)
        {
            MoveTowardsPlayer();
        }
        else
        {
            anim.SetBool("IsRunning", false);  // No está siguiendo
            rb.linearVelocity = Vector2.zero;
        }
    }

    void MoveTowardsPlayer()
    {
        Vector2 direction = (player.position - transform.position).normalized;
        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, obstacleDetectionDistance);

        // Si se detecta un obstáculo, cambia la dirección
        if (hit.collider != null)
        {
            // Aquí estamos detectando si hay un obstáculo en frente del enemigo
            Debug.DrawRay(transform.position, direction * obstacleDetectionDistance, Color.red);  // Mostrar raycast en la vista de Scene
            direction = GetAvoidanceDirection(direction);  // Cambiar la dirección para evitar el obstáculo
        }

        // Mover al enemigo hacia el jugador
        rb.linearVelocity = direction * speed;

        // Voltear el sprite según la dirección
        FlipSprite(direction);

        anim.SetBool("IsRunning", true);  // Activar animación de correr
    }

    // Método para obtener una dirección de esquiva
    Vector2 GetAvoidanceDirection(Vector2 direction)
    {
        // Probar hacia la izquierda
        RaycastHit2D hitLeft = Physics2D.Raycast(transform.position, new Vector2(direction.y, -direction.x), obstacleDetectionDistance);
        if (hitLeft.collider == null) return new Vector2(direction.y, -direction.x);  // Si no hay obstáculo, esquivar hacia la izquierda

        // Probar hacia la derecha
        RaycastHit2D hitRight = Physics2D.Raycast(transform.position, new Vector2(-direction.y, direction.x), obstacleDetectionDistance);
        if (hitRight.collider == null) return new Vector2(-direction.y, direction.x);  // Si no hay obstáculo, esquivar hacia la derecha

        // Si no hay forma de esquivar, sigue al jugador
        return direction;
    }

    // Voltear el sprite del enemigo según la dirección
    void FlipSprite(Vector2 direction)
    {
        if (direction.x > 0)
            spriteRenderer.flipX = false;  // Mirando a la derecha
        else if (direction.x < 0)
            spriteRenderer.flipX = true;  // Mirando a la izquierda
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("ToolCollider")) // Asegúrate de que el arma tenga este tag
        {
            BoxCollider2D weaponCollider = collision.GetComponent<BoxCollider2D>();
            
            if (weaponCollider != null && weaponCollider.enabled) // Solo si el arma está activa
            {
                PlayerAtribute player = collision.GetComponentInParent<PlayerAtribute>(); // Obtener referencia al player
                if (player != null)
                {
                    TakeDamage(player.attackPoints);
                }
            }
        }

        if (collision.CompareTag("Player"))
        {
            PlayerAtribute playerAttributes = collision.GetComponent<PlayerAtribute>();
            
            if (playerAttributes != null)
            {
                playerAttributes.TakeDamage(playerAttributes.attackPoints);
                Debug.Log("El jugador ha recibido daño: " + playerAttributes.attackPoints);
            }
        }
    }


    public void TakeDamage(int damage)
    {
        health -= damage;
        Debug.Log("Enemigo recibe daño: " + damage + " Vida restante: " + health);

        StartCoroutine(ApplyKnockback());

        if (health <= 0)
        {
            Die();
        }
    }

    IEnumerator ApplyKnockback()
    {
        isKnockedBack = true;
        Vector2 knockbackDirection = (transform.position - player.position).normalized;
        rb.AddForce (knockbackDirection * knockbackForce, ForceMode2D.Impulse);

        yield return new WaitForSeconds(0.2f);  // Duración del knockback

        isKnockedBack = false;
    }

    void Die()
    {
        Debug.Log("Enemigo derrotado!");
        anim.SetBool("IsDead", true);

        if (dropItem != null)
        {
            Instantiate(dropItem, transform.position, Quaternion.identity);
        }

        Destroy(gameObject, 0.5f);  // Destruir el enemigo después de 2 segundos
    }
}
