using UnityEngine;
using System.Collections;

public class OrcIA : MonoBehaviour
{
    public Transform player;  // Referencia al jugador
    public float detectionRange = 10f;  // Rango de detección para el jugador
    public float speed = 3f;  // Velocidad de movimiento del enemigo
    public float obstacleDetectionDistance = 2f;  // Distancia para detectar obstáculos
    public float knockbackForce = 3f;  // Fuerza de retroceso
    public int health = 20;
    public int attackDamage = 4;
    public GameObject dropItem; // Item que soltará al morir

    private Animator anim;
    private SpriteRenderer spriteRenderer;
    private Rigidbody2D rb;
    private bool isKnockedBack = false;

    public float attackRange = 1.2f; // Distancia mínima para atacar
    private bool isAttacking = false;
    private bool isRunning = false;
    private bool isIdle = true;

    public Transform swordObject; //El hijo que tiene el arma
    private BoxCollider2D swordCollider; //Collider del arma

    private WorldObject worldObject; 
    private PlayerAtribute playerAtribute;

    void Start()
    {
        anim = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        swordCollider = swordObject.GetComponent<BoxCollider2D>();
        worldObject = GetComponent<WorldObject>();
        playerAtribute = GetComponentInParent<PlayerAtribute>(); // Obtener referencia al player
    }

    void Update()
    {
        if (player == null || isKnockedBack) return;

        float distance = Vector2.Distance(transform.position, player.position);

        if (distance <= attackRange)
        {
            rb.linearVelocity = Vector2.zero;
            isRunning = false;
            UpdateDirection(player.position);
            SetBlendTreeStates();

            if (!isAttacking)
            {
                StartCoroutine(AttackPlayer());
            }
        }
        else if (distance < detectionRange)
        {
            isRunning = true;
            MoveTowardsPlayer();
        }
        else
        {
            isRunning = false;
            rb.linearVelocity = Vector2.zero;
            isAttacking = false;
            UpdateDirection(player.position);
            SetBlendTreeStates();
        }
    }

    IEnumerator AttackPlayer()
    {
        isAttacking = true;
        SetBlendTreeStates();

        // Detener el movimiento y mirar al jugador
        rb.linearVelocity = Vector2.zero;
        UpdateDirection(player.position);
        
        yield return new WaitForSeconds(0.4f);

        isAttacking = false;
        isIdle = true;

    }



   void MoveTowardsPlayer()
    {
        Vector2 direction = (player.position - transform.position).normalized;
        RaycastHit2D hit = Physics2D.Raycast(transform.position, direction, obstacleDetectionDistance);

        if (hit.collider != null)
        {
            Debug.DrawRay(transform.position, direction * obstacleDetectionDistance, Color.red);
            direction = GetAvoidanceDirection(direction);
        }

        rb.linearVelocity = direction * speed;

        UpdateDirection(player.position);
        SetBlendTreeStates();
    }


    // Método para obtener una dirección de esquiva
    Vector2 GetAvoidanceDirection(Vector2 direction)
    {
        // Probar hacia la izquierda
        RaycastHit2D hitLeft = Physics2D.Raycast(transform.position, new Vector2(direction.y, -direction.x), obstacleDetectionDistance);
        if (hitLeft.collider == null) return new Vector2(direction.y, -direction.x);  // Si no hay obstáculo, esquivar hacia la izquierda

        // Probar hacia la derecha
        RaycastHit2D hitRight = Physics2D.Raycast(transform.position, new Vector2(-direction.y, direction.x), obstacleDetectionDistance);
        if (hitRight.collider == null) return new Vector2(-direction.y, direction.x);  // Si no hay obstáculo, esquivar hacia la derecha

        // Si no hay forma de esquivar, sigue al jugador
        return direction;
    }

    //Detectamos la dirección y ajustamos el sprite y collider
    void UpdateDirection(Vector2 targetPosition)
    {
        Vector2 diff = targetPosition - (Vector2)transform.position;
        Vector2 direction = diff.normalized;

        anim.SetFloat("DirectionX", direction.x);
        anim.SetFloat("DirectionY", direction.y);

        // Voltear sprite 
        spriteRenderer.flipX = (direction.x < 0);
        FlipWeaponCollider();
    }

    // Voltear el boxCollider del objeto hijo
    void FlipWeaponCollider()
    {
        if (swordCollider == null) return;

        Vector2 offset = swordCollider.offset;
        offset.x = Mathf.Abs(offset.x) * (spriteRenderer.flipX ? -1f : 1f);
        swordCollider.offset = offset;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
            if (collision.CompareTag("ToolCollider")) // arma del jugador
            {
                PlayerAtribute player = collision.GetComponentInParent<PlayerAtribute>();
                if (player != null)
                {
                    TakeDamage(player.attackPoints);
                }
            }
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
        Debug.Log("Enemigo recibe daño: " + damage + " Vida restante: " + health);

        StartCoroutine(ApplyKnockback());

        if (health <= 0)
        {
            Die();
        }
    }

    IEnumerator ApplyKnockback()
    {
        isKnockedBack = true;
        Vector2 knockbackDirection = (transform.position - player.position).normalized;
        rb.AddForce (knockbackDirection * knockbackForce, ForceMode2D.Impulse);

        yield return new WaitForSeconds(0.2f);  // Duración del knockback

        isKnockedBack = false;
    }

    void SetBlendTreeStates()
    {
        anim.SetBool("isIdle", !isRunning && !isAttacking);
        anim.SetBool("isRun", isRunning);
        anim.SetBool("isAttack", isAttacking);
    }


    void Die()
    {
        Debug.Log("Enemigo derrotado!");
        anim.SetBool("isDead", true);

        if (dropItem != null)
        {
            Instantiate(dropItem, transform.position, Quaternion.identity);
        }

        if (worldObject != null)
        {
            worldObject.DestroyObject();
        }
        else
        {
            Destroy(gameObject);
        }

    }
}

