using UnityEngine;
using System.Collections;

public class Orc : MonoBehaviour
{
    public Transform pointA; // Punto A
    public Transform pointB; // Punto B
    public float speed = 2f; // Velocidad de movimiento
    public int health = 20; // Vida del enemigo
    public int attackDamage = 4; // Daño al jugador
    public GameObject dropItem; // Objeto que dropea al morir
    public float knockbackForce = 3f; // Fuerza de retroceso cuando recibe daño

    private Transform targetPoint; // El punto hacia el que se mueve el enemigo
    private Rigidbody2D rb;
    Animator animator;
    private SpriteRenderer sprite;
    private bool isWaiting = false;
    private bool isKnockedBack = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();

        targetPoint = pointB; // Inicialmente el enemigo va hacia el punto B
        animator.SetBool("IsRunning", true);
    }

    void Update()
    {
        if (!isWaiting && !isKnockedBack)
        {
            MoveBetweenPoints();
        }
    }

    void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0); // Evita movimiento en Y
    }


    void MoveBetweenPoints()
    {
        // Moverse hacia el punto objetivo (A o B)
        Vector2 direction = (targetPoint.position - transform.position).normalized;
        rb.linearVelocity = direction * speed; // Corrección aquí

        // voltear sprite
        if (direction.x > 0)
        {
            sprite.flipX = false;
        }
        else if (direction.x < 0)
        {
            sprite.flipX = true;
        }

        // Si llega al punto objetivo,esperar 3 segundos y cambiar al siguiente punto
        if (Vector2.Distance(transform.position, targetPoint.position) < 0.5f)
        {
            StartCoroutine(WaitBeforeMoving());
        }
    }

    IEnumerator WaitBeforeMoving()
    {
        isWaiting = true;
        rb.linearVelocity = Vector2.zero;
        animator.SetBool("IsRunning", false);
        yield return new WaitForSeconds(2f);
        targetPoint = (targetPoint == pointA) ? pointB : pointA;
        animator.SetBool("IsRunning", true);
        isWaiting = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("ToolCollider")) // Asegúrate de que el arma tenga este tag
        {
            BoxCollider2D weaponCollider = collision.GetComponent<BoxCollider2D>();
            
            if (weaponCollider != null && weaponCollider.enabled) // Solo si el arma está activa
            {
                PlayerAtribute player = collision.GetComponentInParent<PlayerAtribute>(); // Obtener referencia al player
                if (player != null)
                {
                    TakeDamage(player.attackPoints);
                }
            }
        }

        if (collision.CompareTag("Player"))
        {
            PlayerAtribute playerAttributes = collision.GetComponent<PlayerAtribute>();
            
            if (playerAttributes != null)
            {
                playerAttributes.TakeDamage(playerAttributes.attackPoints);
                Debug.Log("El jugador ha recibido daño: " + playerAttributes.attackPoints);
            }
        }
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
        Debug.Log("Enemigo recibe daño: " + damage + " Vida restante: " + health);

        // Aplicar knockback
        StartCoroutine(ApplyKnockback());

        if (health <= 0)
        {
            Die();
        }
    }

    IEnumerator ApplyKnockback()
    {
        isKnockedBack = true;
        rb.linearVelocity = Vector2.zero;

        Vector2 knockbackDirection = (transform.position - targetPoint.position).normalized;
        rb.linearVelocity = knockbackDirection * knockbackForce;

        yield return new WaitForSeconds(0.2f);

        isKnockedBack = false;
    }

    void Die()
    {
        Debug.Log("Enemigo derrotado!");
        animator.SetBool("IsDead", true);
        rb.linearVelocity = Vector2.zero;
        this.enabled = false;

        if (dropItem != null)
        {
            Instantiate(dropItem, transform.position, Quaternion.identity);
        }
        Destroy(gameObject, 0.5f);
    }
}
