using UnityEngine;
using TMPro;

public class CraftingStation : MonoBehaviour
{
    public GameObject infoPanel; // Panel de información
    public TextMeshProUGUI infoText; // Texto de información
    public GameObject inventoryPanel; // Panel de inventario
    public GameObject craftPanel; // Panel de fabricación
    public GameObject equipPanel; // Panel de equipo

    private bool isPlayerInRange = false;
    
    void Update()
    {
        if (isPlayerInRange)
        {
            if (Input.GetKeyDown(KeyCode.I))
            {
                OpenCraftingMenu();
            }
        }
    }

    private void OpenCraftingMenu()
    {
        craftPanel.SetActive(true);        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = true;
            ShowInfoMessage("Pulsa 'I' para fabricar objetos");
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = false;
            HideInfoMessage();
            craftPanel.SetActive(false);
            equipPanel.SetActive(true);
        }
    }

    private void ShowInfoMessage(string message)
    {
        if (infoPanel != null && infoText != null)
        {
            infoPanel.SetActive(true);
            infoText.text = message;
        }
    }

    private void HideInfoMessage()
    {
        if (infoPanel != null)
        {
            infoPanel.SetActive(false);
        }
    }
}
