using UnityEngine;

public class OrcWeaponCollider : MonoBehaviour
{
    public int damage = 4;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            PlayerAtribute player = collision.GetComponent<PlayerAtribute>();
            if (player != null)
            {
                player.TakeDamage(damage);
                Debug.Log("Jugador golpeado por espada del orco: -" + damage);
            }
        }
    }
}
