using System;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "NewRecipe", menuName = "Crafting/Recipe", order = 1)] // Esto te permitirá crear una receta desde el menú de Unity
public class Recipe : ScriptableObject
{
    public GameObject resultPrefab; // El item del objeto creado
    public List<MaterialRequired> materialsRequired; // Lista de materiales requeridos

    [System.Serializable]
    public class MaterialRequired
    {
        public MaterialType materialType; // Prefab del material
        public int amount; // Cantidad necesaria del material
    }
}


