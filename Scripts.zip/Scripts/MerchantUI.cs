using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MerchantUI : MonoBehaviour
{
    public GameObject itemButtonPrefab;
    public Transform merchantItemList;
    public InventoryManager inventoryManager;
    public ItemDatabase itemDatabase;
    public PlayerAtribute player;
    public InventoryUI inventoryUI;
    public GameObject equipmentPanel;
    public GameObject inventory;
    public GameObject merchantPanel;

    void OnEnable()
    {
        inventory.SetActive(true);
        UpdateMerchantList();
    }

    public void UpdateMerchantList()
    {
        foreach (Transform child in merchantItemList)
            Destroy(child.gameObject);

        foreach (var item in itemDatabase.allItems)
        {
            GameObject button = Instantiate(itemButtonPrefab, merchantItemList);
            button.GetComponentInChildren<TextMeshProUGUI>().text = item.itemName + " (" + item.price + " monedas)";
            button.GetComponent<Button>().onClick.AddListener(() =>
            {
                if (player.coins >= item.price)
                {
                    inventoryManager.AddItem(item, 1);
                    player.AddCoins((int)-item.price);
                    inventoryUI.UpdateInventoryUI();
                }
                else
                {
                    Debug.Log("No tienes suficiente oro.");
                }
            });
        }
    }

    public void CloseMerchant()
    {
        equipmentPanel.SetActive(true);
        merchantPanel.SetActive(false);
        Time.timeScale = 1;
    }
}
