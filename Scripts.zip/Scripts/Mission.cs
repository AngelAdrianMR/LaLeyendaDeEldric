using System;

[System.Serializable]
public class Mission
{
    public string id;
    public string missionName;
    public string description;
    public int coinReward = 0;

    public string requieredItemName;
    public bool requieredCrafting = false;

    public bool isActive = false;
    public bool isCompleted = false;
    
    public string nextMissionId;

    public Mission(string id, string name, string description)
    {
        this.id = id;
        this.missionName = name;
        this.description = description;
    }

    public void Activate()
    {
        isActive = true;
        isCompleted = false;
    }

    public void Complete()
    {
        isActive = false;
        isCompleted = true;
    }
}
