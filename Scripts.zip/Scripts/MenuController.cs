using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class MenuController : MonoBehaviour
{
    public void StartNewGame()
    {
        PlayerPrefs.SetInt("LoadGame", 0);
        SceneManager.LoadScene("NewGame");
    }

    public void LoadGame()
    {
        StartCoroutine(LoadSceneAsync("SampleScene"));
        PlayerPrefs.SetInt("LoadGame", 1);
    }

    private IEnumerator LoadSceneAsync(string sceneName)
    {
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
        
        // Esperar hasta que la escena haya terminado de cargar
        while (!asyncLoad.isDone)
        {
            yield return null;
        }

        
    }

}
