using UnityEngine;
using TMPro;

public class NPCDialogue : MonoBehaviour
{
    [Header("UI")]
    public GameObject dialoguePanel;
    public TextMeshProUGUI dialogueText;

    [Header("Tooltip")]
    public GameObject tooltipPanel;
    public TextMeshProUGUI tooltipText;
    public string tooltipMessage = "Pulsa E para hablar";

    [Header("Diálogo")]
    [TextArea(3, 5)]
    public string[] dialogueLines;

    [Header("Misión que activa este NPC")]
    public string missionToGiveId;


    private int currentLine = 0;
    private bool isPlayerInRange = false;
    private bool isDialogueActive = false;

    void Start()
    {
        if (dialoguePanel != null)
            dialoguePanel.SetActive(false);

        if (tooltipPanel != null)
            tooltipPanel.SetActive(false);
    }

    void Update()
    {
        if (isPlayerInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (!isDialogueActive)
            {
                StartDialogue();
            }
            else
            {
                NextLine();
            }
        }
    }

    void StartDialogue()
    {
        currentLine = 0;
        isDialogueActive = true;
        dialoguePanel.SetActive(true);
        dialogueText.text = dialogueLines[currentLine];

        // Oculta el tooltip al iniciar diálogo
        if (tooltipPanel != null)
            tooltipPanel.SetActive(false);
    }

    void NextLine()
    {
        currentLine++;

        if (currentLine < dialogueLines.Length)
        {
            dialogueText.text = dialogueLines[currentLine];
        }
        else
        {
            EndDialogue();
        }
    }

    void EndDialogue()
    {
        isDialogueActive = false;
        dialoguePanel.SetActive(false);

        if (!string.IsNullOrEmpty(missionToGiveId))
        {
            Mission existing = MissionManager.Instance.GetMissionById(missionToGiveId);
            if (existing == null)
            {
                MissionManager.Instance.AddMissionById(missionToGiveId);
            }
        }

        Debug.Log("Diálogo terminado.");
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = true;

            if (!isDialogueActive && tooltipPanel != null && tooltipText != null)
            {
                tooltipPanel.SetActive(true);
                tooltipText.text = tooltipMessage;
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = false;

            if (tooltipPanel != null)
                tooltipPanel.SetActive(false);

            if (isDialogueActive)
                EndDialogue();
        }
    }
}
