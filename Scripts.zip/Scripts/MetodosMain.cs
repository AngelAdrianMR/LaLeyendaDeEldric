using UnityEngine;
using UnityEngine.SceneManagement;
using System.IO;

public class MetodosMain : MonoBehaviour
{
    private GameManager gameManager;

    void Start()
    {
        gameManager = FindFirstObjectByType<GameManager>();

        if (gameManager == null)
        {
            Debug.LogError("No se encontró GameManager en la escena");
        }
    }

    public void Load()
    {
        if (gameManager != null)
        {
            string filePath = @"C:/Users/Angel/AppData/LocalLow/DefaultCompany/My project (3)/saveData.json";
            Debug.Log("Buscando archivo en: " + filePath);

            if (File.Exists(filePath))
            {
                Debug.Log("Archivo encontrado. Cargando juego...");
                gameManager.LoadGame();
            }
            
        }
        else
        {
            Debug.LogError("GameManager no está inicializado.");
        }
    }

}
