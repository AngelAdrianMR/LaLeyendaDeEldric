using UnityEngine;

public class ItemPickup : MonoBehaviour
{
    public Item item; // Objeto representado por este pickup

    private WorldObject worldObject;

    void Start() 
    {
        worldObject = GetComponent<WorldObject>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerMovement player = other.GetComponent<PlayerMovement>();
            if (player != null)
            {
                player.nearbyItem = this; // Asigna este objeto como el item cercano
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerMovement player = other.GetComponent<PlayerMovement>();
            if (player != null && player.nearbyItem == this)
            {
                player.nearbyItem = null; // Borra la referencia si el jugador se aleja
            }
        }
    }

    public void PickupItem()
    {
        InventoryManager inventoryManager = FindFirstObjectByType<InventoryManager>();
        inventoryManager.AddItem(item);  // Aquí asignamos el Item al inventario
        
        // Actualizar la UI después de recoger el ítem
        FindFirstObjectByType<InventoryUI>().UpdateInventoryUI();

        if (worldObject != null)
        {
            Debug.Log("El item fue guardado");
            worldObject.DestroyObject(); // Llama al método del script WorldObject
        }
        else
        {
            Destroy(gameObject); // Si por algún motivo no tiene WorldObject, destrúyelo de forma normal
        }
    }
}
