using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
    private string saveFilePath;
    private PlayerAtribute player;
    private PlayerMovement playerMovement;
    private InventoryManager inventoryManager;
    private GameManager gameManager;

    //IDs de objetos destruidos
    private HashSet<string> destroyedObjects = new HashSet<string>();

    void Awake()
    {
        saveFilePath = Path.Combine(Application.persistentDataPath, "saveData.json");

        int loadGame = PlayerPrefs.GetInt("LoadGame", 0);

        if (loadGame == 1)
        {
            Debug.Log("Cargando partida guardada...");
            LoadGame();
        }
        else 
        {
            Debug.Log("Cargando nueva partida.");
        }
    }

    void Start()
    {
        player = FindFirstObjectByType<PlayerAtribute>();
        playerMovement = FindFirstObjectByType<PlayerMovement>();
        inventoryManager = FindFirstObjectByType<InventoryManager>();
        gameManager = FindFirstObjectByType<GameManager>();

        // Comprobamos si alguno de los objetos es null.
        if (player == null)
        {
            Debug.LogError("PlayerAtribute no encontrado en la escena.");
        }
        if (playerMovement == null)
        {
            Debug.LogError("PlayerMovement no encontrado en la escena.");
        }
        if (inventoryManager == null)
        {
            Debug.LogError("InventoryManager no encontrado en la escena.");
        }
    }

    public void SaveGame()
    {
        SaveData data = new SaveData(player, playerMovement, inventoryManager, this);

        // Crear un objeto InventoryData
        InventoryData inventoryData = new InventoryData();

        // Agregar los nombres de los items y sus cantidades
        foreach (var kvp in inventoryManager.inventory)
        {
            inventoryData.itemNames.Add(kvp.Key.itemName);  // Asumiendo que 'kvp.Key' es un 'Item' que tiene 'itemName'
            inventoryData.itemQuantities.Add(kvp.Value);    // Asumiendo que 'kvp.Value' es la cantidad del item
        }

        // Guardar los elementos equipados
        foreach (var equip in inventoryManager.equippedItems)
        {
            inventoryData.equippedItems.Add(equip.Key, equip.Value);
        }

        // Guardar el objeto InventoryData en el SaveData
        data.inventoryData = inventoryData;

        // Guardar el JSON
        string json = JsonUtility.ToJson(data, true);
        File.WriteAllText(saveFilePath, json);
        Debug.Log("Juego guardado en: " + saveFilePath);
    }



    public void LoadGame()
    {
        // Busca los objetos en la nueva escena
        player = FindFirstObjectByType<PlayerAtribute>();
        playerMovement = FindFirstObjectByType<PlayerMovement>();
        inventoryManager = FindFirstObjectByType<InventoryManager>();
        gameManager = FindFirstObjectByType<GameManager>();

        // Verifica si los objetos fueron encontrados
        if (player == null)
        {
            Debug.LogError("No se encontró PlayerAtribute en la escena.");
        }
        if (playerMovement == null)
        {
            Debug.LogError("No se encontró PlayerMovement en la escena.");
        }
        if (inventoryManager == null)
        {
            Debug.LogError("No se encontró InventoryManager en la escena.");
        }

        // Si los objetos fueron encontrados, carga los datos del juego
        if (player != null && playerMovement != null && inventoryManager != null)
        {
            if (File.Exists(saveFilePath))
            {
                string json = File.ReadAllText(saveFilePath);
                SaveData data = JsonUtility.FromJson<SaveData>(json);
                data.LoadInto(player, playerMovement, inventoryManager, this);
                
                Debug.Log("Cargando inventario");
                inventoryManager.LoadInventoryData(data.inventoryData);

                Debug.Log("cargando lista de objetos destruidos...");
                SetDestroyedObjects(data.destroyedObjects);

                Debug.Log("Juego cargado.");
            }
            else
            {
                Debug.LogWarning("No hay partida guardada.");
            }
        }

        InventoryUI inventoryUI = FindFirstObjectByType<InventoryUI>();

        if (inventoryUI != null)
        {
            inventoryUI.UpdateInventoryUI();
            inventoryUI.UpdateEquipmentUI();
        }
    }

    public void ExitToMainMenu()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("Main");
    }


    public List<string> GetDestroyedObjects()
    {
        return new List<string>(destroyedObjects);
    }

    public void SetDestroyedObjects(List<string> loadedObjects)
    {
        destroyedObjects = new HashSet<string>(loadedObjects);

        // ✅ Buscar manualmente en todos los WorldObject y eliminarlos
        WorldObject[] allObjects = FindObjectsByType<WorldObject>(FindObjectsSortMode.None);

        // Eliminar objetos en la escena
        foreach (string objectID in destroyedObjects)
        {
            foreach (WorldObject obj in allObjects)
            {
                if (obj.objectID == objectID)
                {
                    Debug.Log("Eliminando objeto tras carga: " + objectID);
                    Destroy(obj.gameObject);
                }
            }
        }
    }


    public void RegisterDestroyedObject(string objectID)
    {
        destroyedObjects.Add(objectID);
    }

    public bool IsObjectDestroyed(string objectID)
    {
        return destroyedObjects.Contains(objectID);
    }

    private GameObject FindObjectByID(string objectID)
    {
        WorldObject[] allObjects = FindObjectsByType<WorldObject>(FindObjectsSortMode.None);
        foreach (WorldObject obj in allObjects)
        {
            if (obj.objectID == objectID)
            {
                return obj.gameObject;
            }
        }
        return null;
    }

}
