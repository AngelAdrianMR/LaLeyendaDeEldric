using UnityEngine;
using UnityEngine.EventSystems;

public class InventorySlot : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, IPointerClickHandler
{
    private Item item; // El ítem asignado al slot
    private GameObject merchantPanel; // Asignar desde InventoryUI

    private PlayerAtribute player;
    private InventoryManager inventory;

    void Start()
    {
        player = FindObjectOfType<PlayerAtribute>();
        inventory = FindObjectOfType<InventoryManager>();
        merchantPanel = GameObject.Find("MerchantPanel");
    }

    public void SetItem(Item newItem)
    {
        item = newItem;
        Debug.Log("Item asignado al slot: " + (item != null ? item.itemName : "null"));

    }

    // Al pasar el ratón por encima del slot
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (item != null)
        {
            Debug.Log("Item sobre el cual pasas el ratón: " + item.itemName);
            // Mostrar tooltip
            InventoryTooltip.instance.ShowTooltip(item);
        }
    }

    // Al salir el ratón del slot
    public void OnPointerExit(PointerEventData eventData)
    {
        Debug.Log("El ratón ha salido del slot");
        // Ocultar el tooltip
        InventoryTooltip.instance.HideTooltip();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (merchantPanel != null && merchantPanel.activeSelf && item != null)
        {
            if (player != null && inventory != null)
            {
                inventory.RemoveItem(item);
                player.AddCoins((int)item.price);
                Debug.Log($"Vendiste {item.itemName} por {item.price} monedas.");

                // Actualizar UI manualmente si es necesario
                FindObjectOfType<InventoryUI>()?.UpdateInventoryUI();
            }
        }
    }
}
