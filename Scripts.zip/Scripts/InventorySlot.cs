using UnityEngine;
using UnityEngine.EventSystems;

public class InventorySlot : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    private Item item; // El ítem asignado al slot

    public void SetItem(Item newItem)
    {
        item = newItem;
        Debug.Log("Item asignado al slot: " + (item != null ? item.itemName : "null"));

    }

    // Al pasar el ratón por encima del slot
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (item != null)
        {
            Debug.Log("Item sobre el cual pasas el ratón: " + item.itemName);
            // Mostrar tooltip
            InventoryTooltip.instance.ShowTooltip(item);
        }
    }

    // Al salir el ratón del slot
    public void OnPointerExit(PointerEventData eventData)
    {
        Debug.Log("El ratón ha salido del slot");
        // Ocultar el tooltip
        InventoryTooltip.instance.HideTooltip();
    }
}
