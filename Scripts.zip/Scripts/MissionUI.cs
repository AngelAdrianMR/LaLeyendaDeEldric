using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections.Generic;

public class MissionUI : MonoBehaviour
{
    public GameObject missionPanel;
    public GameObject missionEntryPrefab;
    public Transform missionListActiveContent;
    public Transform missionListCompletedContent;

    public TextMeshProUGUI titleText;
    public TextMeshProUGUI descriptionText;

    private void Start()
    {
        missionPanel.SetActive(false);
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.J))
        {
            bool isActive = missionPanel.activeSelf;
            missionPanel.SetActive(!isActive);

            if (!isActive)
            {
                RefreshMissionUI();
            }
        }
    }

    public void PopulateMissionList()
    {
        // Limpiar ambas listas
        foreach (Transform child in missionListActiveContent)
            Destroy(child.gameObject);

        foreach (Transform child in missionListCompletedContent)
            Destroy(child.gameObject);

        // Misiones activas
        foreach (var mission in MissionManager.Instance.activeMissions)
            CreateMissionEntry(mission, false, missionListActiveContent);

        // Misiones completadas
        foreach (var mission in MissionManager.Instance.completedMissions)
            CreateMissionEntry(mission, true, missionListCompletedContent);
    }


    void CreateMissionEntry(Mission mission, bool isCompleted, Transform parent)
    {
        GameObject entry = Instantiate(missionEntryPrefab, parent);
        TextMeshProUGUI text = entry.GetComponentInChildren<TextMeshProUGUI>();
        text.text = mission.missionName + (isCompleted ? " (Completada)" : "");

        Button btn = entry.GetComponent<Button>();
        if (btn != null)
        {
            btn.onClick.AddListener(() =>
            {
                ShowMissionDetails(mission);
            });
        }
    }

    void ShowMissionDetails(Mission mission)
    {
        titleText.text = mission.missionName;
        descriptionText.text = mission.description;
    }

    public void RefreshMissionUI()
    {
        PopulateMissionList(); // Vuelve a construir toda la lista
    }

}
