using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "MissionDatabase", menuName = "Misiones/Mission Database")]
public class MissionDatabase : ScriptableObject
{
    public List<Mission> allMissions;

    public Mission GetMissionById(string id)
    {
        return allMissions.Find(m => m.id == id);
    }
}
