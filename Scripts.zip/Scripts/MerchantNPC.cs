using UnityEngine;
using TMPro;

public class MerchantNPC : MonoBehaviour
{
    public GameObject tooltipPanel;
    public TextMeshProUGUI tooltipText;
    public GameObject merchantUI; // Este debe ser el panel que contiene todo el comercio
    public GameObject inventory;

    private bool isPlayerInRange;
    private bool isPanelOpen = false;

    void Start()
    {
        tooltipPanel.SetActive(false);
        merchantUI.SetActive(false);
    }

    void Update()
    {
        if (isPlayerInRange && Input.GetKeyDown(KeyCode.E))
        {
            if (isPanelOpen)
            {
                CloseMerchantPanel();
            }
            else
            {
                OpenMerchantPanel();
            }
        }
    }

    void OpenMerchantPanel()
    {
        inventory.SetActive(true);
        merchantUI.SetActive(true);
        Time.timeScale = 0f;
        isPanelOpen = true;
    }

    void CloseMerchantPanel()
    {
        inventory.SetActive(false);
        merchantUI.SetActive(false);
        Time.timeScale = 1f;
        isPanelOpen = false;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = true;
            tooltipPanel.SetActive(true);
            tooltipText.text = "Pulsa E para comerciar";
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            isPlayerInRange = false;
            tooltipPanel.SetActive(false);

            // Si el jugador se aleja, cierra el panel
            if (isPanelOpen)
            {
                CloseMerchantPanel();
            }
        }
    }
}
