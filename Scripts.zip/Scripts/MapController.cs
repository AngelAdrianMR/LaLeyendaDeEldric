using UnityEngine;
using UnityEngine.UI;

public class MapController : MonoBehaviour
{
    public GameObject mapPanel; // Panel del mapa
    public RectTransform mapImage; // Referencia a la imagen del mapa
    private Vector2 lastMousePosition;
    private bool isDragging = false;

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.M))
        {
            mapPanel.SetActive(!mapPanel.activeSelf);
        }

        if (mapPanel.activeSelf)
        {
            HandleMapMovement();
        }
    }

    void HandleMapMovement()
    {
        if (Input.GetMouseButtonDown(0))
        {
            isDragging = true;
            lastMousePosition = Input.mousePosition;
        }
        if (Input.GetMouseButtonUp(0))
        {
            isDragging = false;
        }
        if (isDragging)
        {
            Vector2 delta = (Vector2)Input.mousePosition - lastMousePosition;
            mapImage.anchoredPosition += delta;
            lastMousePosition = Input.mousePosition;
        }
    }
}
