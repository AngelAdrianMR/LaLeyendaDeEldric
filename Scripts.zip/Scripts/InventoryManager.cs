using System.Collections.Generic;
using UnityEngine;
using System.Linq;
using System;

[System.Serializable]
public class InventoryData
{
    public List<string> itemNames = new List<string>();
    public List<int> itemQuantities = new List<int>();
    public Dictionary<ItemType, string> equippedItems = new Dictionary<ItemType, string>();
}

public class InventoryManager : MonoBehaviour
{
    public ItemDatabase ItemDatabase;
    private Dictionary<string, Item> itemDictionary = new Dictionary<string, Item>();

    public Dictionary<Item, int> inventory = new Dictionary<Item, int>(); // Lista de objetos en el inventario
    public const int maxInventorySize = 49;
    public Dictionary<ItemType, string> equippedItems = new Dictionary<ItemType, string>(); // Objetos equipados

    private PlayerAtribute playerAtribute;
    private PlayerMovement playerMovement;
    private InventoryUI inventoryUI;
    public GameObject player;


    void Awake()
    {
        foreach (var item in ItemDatabase.allItems)
        {
            itemDictionary[item.itemName.ToLower()] = item;
        }

        if (inventoryUI == null)
        {
            inventoryUI = FindObjectOfType<InventoryUI>();
        }
    }

    void Start()
    {
        // Obtener los componentes PlayerAtribute y PlayerMovement del jugador
        if (player != null)
        {
            playerAtribute = player.GetComponent<PlayerAtribute>();
            playerMovement = player.GetComponent<PlayerMovement>();
        }

        // Si no se encuentran los componentes, muestra un error
        if (playerAtribute == null)
        {
            Debug.LogError("El componente PlayerAtribute no está asignado en el jugador.");
        }
        if (playerMovement == null)
        {
            Debug.LogError("El componente PlayerMovement no está asignado en el jugador.");
        }
    }

    public void AddItem(Item item, int quantity = 1)
    {
        if (item == null)
        {
            Debug.LogError("Intentando añadir un item nulo al inventario.");
            return;
        }

        if (item.itemType == ItemType.Material)
        {
            // Buscar si ya tenemos un material de este tipo
            foreach (var kvp in inventory)
            {
                if (kvp.Key.materialType == item.materialType)
                {
                    inventory[kvp.Key] += quantity; // Aumentar cantidad
                    Debug.Log("Añadido " + quantity + " al material existente: " + item.itemName);
                    return;
                }
            }

            // Si no existe, lo añadimos como un nuevo item
            inventory[item] = quantity;
        }
        else
        {
            // Para otros tipos de items, simplemente añadirlos sin apilar
            inventory[item] = quantity;
        }

        Debug.Log("Añadido " + item.itemName + " x" + quantity + " al inventario.");
    }


    public void RemoveItem(Item item, int amountRemove = 1)
    {
        if (inventory.ContainsKey(item))
        {
            if (inventory[item] > amountRemove)
            {
                inventory[item] -= amountRemove; 
            }
            else
            {
                inventory.Remove(item); // Si solo queda 1, lo eliminamos completamente
            }

        }
    }

    public void EquipItem(Item item)
    {
        ItemType itemType = item.itemType;

        if (equippedItems.ContainsKey(item.itemType))
        {
            UnequipItem(item.itemType);
        }
        
        // Guarda el objeto en equipados
        equippedItems[item.itemType] = item.itemName;

        //Aplicamos los efectos del objeto
        ApplyItemEffects(item);
        
        RemoveItem(item);

        inventoryUI.UpdateInventoryUI();
        inventoryUI.UpdateEquipmentUI();
    }

    public void UnequipItem(ItemType itemType)
    {
        if (equippedItems.ContainsKey(itemType))
        {
            string itenName = equippedItems[itemType];
            Item itemToUnequip = GetItemByName(itenName);

            // Volver el objeto al inventario
            if (itemToUnequip != null)
            {
                AddItem(itemToUnequip);
            }

            // Eliminar el objeto del slot equipado
            equippedItems.Remove(itemType);

            // Quitar los efectos del objeto
            if (itemToUnequip != null)
            {
                RemoveItemEffects(itemToUnequip);
            }
        }
    }

    public void UsePotion(Item item)
    {
        if (item != null && item.isPotion)
        {
            // Aplicar los efectos de la poción al jugador
            ApplyPotionEffect(item);

            // Eliminar la poción del inventario después de usarla
            RemoveItem(item);
        }
    }

    private void ApplyItemEffects(Item item)
    {
        if (playerAtribute != null)
        {
            playerAtribute.maxHealth += item.healthBonus;
            playerAtribute.attackPoints += item.attackBonus;
            playerMovement.moveSpeed += item.speedBonus;
        }
    }

    private void ApplyPotionEffect(Item item)
    {
        playerAtribute.currentHealth += item.plusHealth;
        playerAtribute.currentStamina += item.plusStamina;
    }

    private void RemoveItemEffects(Item item)
    {
        if (playerAtribute != null)
        {
            playerAtribute.maxHealth -= item.healthBonus;
            playerAtribute.attackPoints -= item.attackBonus;
            playerMovement.moveSpeed -= item.speedBonus;
        }
    }

    public bool HasEquipped(ItemType itemType)
    {
        return equippedItems.ContainsKey(itemType);
    }

    // Verifica si el jugador tiene suficientes materiales para fabricar un objeto
    public bool HasEnoughItems(MaterialType requiredMaterial, int requiredAmount)
    {
        int count = 0;

        foreach (var item in inventory)
        {
            if (item.Key.materialType == requiredMaterial) // Comparación por tipo en lugar de prefab
            {
                count += item.Value; 
                Debug.Log("Encontrado material: " + item.Key.materialType);
            }
        }

        Debug.Log("Material requerido: " + requiredMaterial + " | Cantidad: " + count + " | Requerido: " + requiredAmount);
        return count >= requiredAmount;
    }

    public InventoryData GetInventoryData()
    {
        InventoryData data = new InventoryData();

        foreach (var item in inventory)
        {
            data.itemNames.Add(item.Key.itemName);
            data.itemQuantities.Add(item.Value);
        }

        foreach (var equip in equippedItems)
        {
            data.equippedItems[equip.Key] = equip.Value;
        }
        return data;
    }

    public void LoadInventoryData(InventoryData data)
    {
        inventory.Clear(); // Limpiar el inventario antes de cargarlo.

        // Cargar items en el inventario
        for (int i = 0; i < data.itemNames.Count; i++)
        {
            string itemName = data.itemNames[i];
            int quantity = data.itemQuantities[i];

            // Obtener el objeto Item por su nombre
            Item item = GetItemByName(itemName);
            if (item != null)
            {
                // Añadir el item al inventario con la cantidad correcta
                AddItem(item, quantity);
                Debug.Log("Item cargado: " + item.itemName + " Cantidad: " + quantity);
            }
            else
            {
                Debug.LogWarning("No se encontró el item con nombre: " + itemName);
            }
        }

        // Cargar los objetos equipados
        foreach (var equippedItem in data.equippedItems)
        {
            string itemName = equippedItem.Value;  // Nombre del ítem equipado
            ItemType itemType = equippedItem.Key;  // Tipo de ítem

            // Obtener el objeto Item por su nombre
            Item item = GetItemByName(itemName);
            if (item != null)
            {
                // Equipar el item
                EquipItem(item);
                ApplyItemEffects(item);  // Aplicar los efectos del item
            }
            else
            {
                Debug.LogWarning("No se encontró el item equipado con nombre: " + itemName);
            }
        }

        inventoryUI.UpdateInventoryUI();
        inventoryUI.UpdateEquipmentUI();
    }

    public Item GetItemByName(string itemName)
    {
        if (string.IsNullOrEmpty(itemName))
        {
            Debug.LogWarning("Intentando buscar un item con nombre vacío.");
            return null;
        }

        string lowerItemName = itemName.ToLower();
        if (itemDictionary.TryGetValue(lowerItemName, out Item item))
        {
            return item;
        }

        Debug.LogWarning($"No se encontró el objeto en la base de datos: {itemName}");
        return null;
    }

}


